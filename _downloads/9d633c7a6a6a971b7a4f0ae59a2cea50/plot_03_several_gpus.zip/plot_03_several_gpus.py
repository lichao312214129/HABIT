"""
Running a cohort on several GPUs
================================

``cap_workers_to_gpu_pool=True`` clamps ``workers`` to the visible GPU
count, one worker per card. Pair it with ``reuse_workers()`` so CUDA
startup is paid once. This machine has one GPU, so the recorded 5-GPU
timings below are from a cloud run and this page does not repeat that
workload. The call itself is in the next cell.
"""

# %%
# The policy a 5-GPU node uses. Building it does not launch workers.
# sphinx_gallery_thumbnail_path = '_static/images/examples/parallel_cloud_speedup.png'
from habit.execution import backend_from_policy
from habit.spec import RunPolicy

policy = RunPolicy(
    workers=5,
    backend="process",
    parallel_mode="persistent",
    cap_workers_to_gpu_pool=True,
    on_subject_failure="fail_fast",
)
backend = backend_from_policy(policy)
print(
    type(backend).__name__,
    "requested_workers=5",
    f"cap={backend.policy.cap_workers_to_gpu_pool}",
    f"workers_after_cap={backend.workers}",
)

# %%
# The call on a multi-GPU machine
# -------------------------------
# Set ``CUDA_VISIBLE_DEVICES`` to the cards before Python starts, for
# example ``0,1,2,3,4``. Leave ``HABIT_GPU_OVERSUBSCRIBE`` unset: each
# worker then keeps one card. On a single GPU the cap leaves one worker;
# extra workers without the cap are sent to CPU
# (:doc:`/auto_examples/06_parallel_runs/plot_01_run_a_cohort`).
#
# ``extractor`` is any per-subject operator, for example
# ``VoxelRadiomicsFeatures``. Do not pin ``torch_device`` to one card:
# a worker reads its slot and takes one visible GPU. The driver for the
# table below is ``scripts/run_multi_gpu_cohort_bench.py``.


def run_on_the_pool(extractor: object, subjects: object) -> list[object]:
    """Map ``extractor`` once per subject, workers kept up across maps.

    Args:
        extractor: Per-subject callable, for example ``VoxelRadiomicsFeatures``.
        subjects: Cohort or any sequence ``backend.map`` accepts.

    Returns:
        One slot per subject. Workers stay up for every ``map`` in the block.
    """
    with backend.reuse_workers():
        return list(backend.map(extractor, subjects))


print("defined run_on_the_pool; workers after the GPU cap:", backend.workers)

# %%
# Recorded AutoDL timings (2026-09-04)
# ------------------------------------
# 5× NVIDIA GeForce RTX 4080 SUPER (32 GiB), 144 logical CPUs, ~503 GiB RAM.
# Synthetic cohort n=16, shape 80×80×48, 90 voxel-texture features.
# Warm rows used ``with backend.reuse_workers():``.
# Full driver: ``scripts/run_multi_gpu_cohort_bench.py``.
#
# .. list-table::
#    :header-rows: 1
#    :widths: 18 22 10 12 12 16 16
#
#    * - Scenario
#      - Device
#      - Workers
#      - Pool
#      - Wall (s)
#      - Subjects/min
#      - Speedup vs CPU serial
#    * - 0 GPU
#      - CUDA=-1 (CPU)
#      - 1
#      - cold
#      - 263.49
#      - 3.64
#      - 1.00×
#    * - 0 GPU
#      - CUDA=-1 (CPU)
#      - 8
#      - cold
#      - 49.16
#      - 19.53
#      - 5.36×
#    * - 1 GPU
#      - CUDA=0
#      - 1
#      - warm
#      - 12.41
#      - 77.33
#      - 21.22×
#    * - 5 GPUs
#      - CUDA=0,1,2,3,4
#      - 5
#      - cold
#      - 14.78
#      - 64.97
#      - 17.83×
#    * - 5 GPUs
#      - CUDA=0,1,2,3,4
#      - 5
#      - warm
#      - 4.16
#      - 231.03
#      - 63.41×
#
# .. figure:: /_static/images/examples/parallel_cloud_speedup.png
#    :alt: Multi-GPU cohort wall time versus worker count
#
#    Recorded AutoDL result (16 subjects, 90 features). Stars are warm
#    persistent pools. This page does not regenerate the figure.
