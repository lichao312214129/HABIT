"""
Extracting a voxel texture
==========================

Input: one :class:`~habit.contracts.Subject`. Output: a
:class:`~habit.contracts.VoxelFeatureField` of per-voxel GLCM Contrast.
Stage: :func:`~habit.voxel_features.extract_voxel_texture`.

GPU paths for the same IBSI texture are in
:doc:`/auto_examples/02_voxel/plot_03_voxel_texture`.
"""

# %%
# Change ``DATA`` / ``MODALITIES`` / ``ROI`` to your preprocessed layout.
# Radius 1 is a 3x3x3 neighbourhood; ``bin_width=25`` matches the GPU page.
# sphinx_gallery_thumbnail_number = 1
from pathlib import Path

import matplotlib.pyplot as plt

from habit.contracts import cohort_from_directory
from habit.datasets import fetch_demo
from habit.viz import plot_voxel_texture_slice
from habit.voxel_features import extract_voxel_texture

DATA = fetch_demo()
MODALITIES = ("LAP",)
ROI = "LAP"
subject = cohort_from_directory(DATA, modalities=MODALITIES, roi=ROI)[0]
image = subject.image(ROI)
mask = subject.mask(ROI)

field = extract_voxel_texture(
    image,
    mask,
    kernel_radius=1,
    bin_width=25.0,
    feature_classes={"glcm": ["Contrast"]},
)
print(field.feature_frame().head())
field.feature_frame().head()

fig = plot_voxel_texture_slice(
    field,
    feature=0,
    anatomy=image,
    roi_mask=mask,
    crop_to="roi",
)
Path("out").mkdir(exist_ok=True)
fig.savefig("out/voxel_texture_field.png", dpi=150, bbox_inches="tight")
plt.show()
