"""
Running subjects in separate processes
======================================

``RunPolicy(workers=2, backend="process")`` builds a
:class:`~habit.execution.ProcessPoolBackend`. Pass that object as
``backend=`` to ``fit_predict``. ``subject_timeout_sec`` is enforced
only on this backend. On Windows the ``map`` call must sit under
``if __name__ == "__main__":``.
"""

# %%
# Building the backend does not start workers. ``map`` does.
# This docs build has no script path, so it stops after printing the backend.
from pathlib import Path

import matplotlib.pyplot as plt

from habit.contracts import Cohort, Subject
from habit.execution import backend_from_policy
from habit.spec import RunPolicy

cohort = Cohort(
    [
        Subject(subject_id="subj001", images={}, masks={}),
        Subject(subject_id="subj002", images={}, masks={}),
        Subject(subject_id="subj003", images={}, masks={}),
    ],
    name="processes",
)

def subject_label(subject: Subject) -> str:
    """Return the subject id. Workers re-import this function."""
    return subject.subject_id

def main() -> None:
    """Build the pool and, when this file is the script, map the cohort."""
    policy = RunPolicy(
        workers=2,
        backend="process",
        parallel_mode="persistent",
        on_subject_failure="continue",
        subject_timeout_sec=30.0,
    )
    backend = backend_from_policy(policy)
    print(type(backend).__name__, backend.workers, backend.policy.subject_timeout_sec)
    # Workers re-import this file. Only the original script should map.
    if "__file__" in globals():
        slots = list(backend.map(subject_label, cohort))
        print([slot.result() for slot in slots])
    fig, ax = plt.subplots(figsize=(6.4, 2.6))
    worker_labels = [f"worker {index + 1}" for index in range(int(backend.workers))]
    ax.barh(worker_labels, [1] * len(worker_labels), color="#4C78A8")
    ax.set_xlabel("slot")
    ax.set_title(f"process pool (timeout {backend.policy.subject_timeout_sec:g} s)")
    Path("out").mkdir(exist_ok=True)
    fig.savefig("out/process_pool.png", dpi=150, bbox_inches="tight")
    plt.show()


if __name__ == "__main__":
    main()
