"""
Load from NumPy arrays
======================

Wrap raw NumPy arrays or deep-learning tensors with
:class:`~habit.contracts.ArrayImageRef` and explicit
:class:`~habit.contracts.Geometry`. Axis order is ``(z, y, x)``;
mask arrays must be **integer labels** (``0`` = background).
"""

# %%
# Read the same demo files, then build a Subject from arrays.
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import SimpleITK as sitk

from habit.contracts import ArrayImageRef, Geometry, Subject
from habit.datasets import fetch_demo
from habit.viz import plot_numpy_ingest
from habit.voxel_features import RawVoxelFeatures

DATA = fetch_demo()
MODALITIES = ("LAP",)
ROI = "LAP"
image_path = next(
    path for path in (DATA / "images" / "subj001" / "LAP").iterdir() if path.is_file()
)
mask_path = next(
    path for path in (DATA / "masks" / "subj001" / "LAP").iterdir() if path.is_file()
)
sitk_image = sitk.ReadImage(str(image_path))
sitk_mask = sitk.ReadImage(str(mask_path))
array = sitk.GetArrayFromImage(sitk_image)
mask = np.asarray(sitk.GetArrayFromImage(sitk_mask), dtype=np.int32)
geometry = Geometry.from_array(
    array.shape,
    spacing=tuple(sitk_image.GetSpacing()),
    origin=tuple(sitk_image.GetOrigin()),
    direction=tuple(sitk_image.GetDirection()),
)
np_subject = Subject(
    subject_id="subj001",
    images={"LAP": ArrayImageRef(array=array, geometry=geometry)},
    masks={"LAP": ArrayImageRef(array=mask, geometry=geometry)},
)
field = RawVoxelFeatures(modalities=["LAP"])(np_subject)
print(
    f"NumPy Subject: id={np_subject.subject_id}, "
    f"LAP shape={np_subject.image('LAP').data.shape}, "
    f"voxels={field.values.shape[0]}"
)
print(field.feature_frame().head())
field.feature_frame().head()

# %%
# Visual summary of this route: the array itself (left, as a colour matrix)
# becomes a plottable Subject (right, zoomed to the ROI).
Path("out").mkdir(exist_ok=True)
fig = plot_numpy_ingest(
    np_subject.image("LAP"),
    roi_mask=np_subject.mask("LAP"),
)
fig.savefig("out/numpy_subject_ingest.png", dpi=150, bbox_inches="tight")
plt.show()
